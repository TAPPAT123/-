const errorHandler = (err, req, res, next) => {
    // Логируем ошибку
    console.error(err);
    res.status(err.status || 500).json({
        message: err.message || 'Внутренняя ошибка сервера',
    });
};

module.exports = errorHandler;