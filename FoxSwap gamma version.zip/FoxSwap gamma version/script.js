const token = localStorage.getItem('token');
const scoreElement = document.getElementById('score');
const tapArea = document.getElementById('tapArea');

// Функция для получения баланса пользователя
async function fetchBalance() {
    const response = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token }),
    });
    const data = await response.json();
    scoreElement.textContent = data.balance;
}

// Обработка нажатия на элемент
async function handleTap(event) {
    // Вибрация (если поддерживается)
    if ("vibrate" in navigator) {
        navigator.vibrate(100);
    }

    // Отправляем запрос на сервер
    await fetch('/api/tap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token }),
    });

    // Отображение анимации
    const tapX = event.clientX;
    const tapY = event.clientY;

    // Создаем элемент для отображения +1
    const coinAdded = document.createElement('div');
    coinAdded.textContent = '+1';
    coinAdded.className = 'add-coins tap-animation';
    document.body.appendChild(coinAdded);
    
    // Позиционирование элемента
    coinAdded.style.left = `${tapX}px`;
    coinAdded.style.top = `${tapY}px`;
    
    // Удаляем элемент после анимации
    setTimeout(() => {
        document.body.removeChild(coinAdded);
    }, 1000);

    // Обновляем баланс на экране
    fetchBalance();
}

// Обработчики событий
tapArea.addEventListener('click', handleTap);
document.getElementById('copyButton').addEventListener('click', () => {
    const referralLink = `https://yourapp.com/ref/${yourTelegramId}`;
    navigator.clipboard.writeText(referralLink).then(() => {
        alert('Ссылка скопирована!');
    });
});

// Инициализация
fetchBalance();
