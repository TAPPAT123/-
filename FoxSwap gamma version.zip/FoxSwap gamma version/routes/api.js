const express = require('express');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Task = require('../models/Task');
const logger = require('../config/logger'); // Импортируем логгер
const router = express.Router();

// Генерация JWT
const generateToken = (user) => {
    return jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
};

// Авторизация
router.post('/auth', async (req, res) => {
    const { id, username } = req.body;

    // Логируем попытку авторизации
    logger.info(`Авторизация пользователя: ${username}`);
    let user = await User.findOne({ telegramId: id });

    // Если пользователь не найден, создаем нового
    if (!user) {
        user = new User({ telegramId: id, referralLink: `https://yourapp.com/ref/${id}` });
        await user.save();
        logger.info(`Создан новый пользователь: ${username}`);
    }

    const token = generateToken(user);
    res.json({ token, balance: user.balance });
});

// Обработка тапов
router.post('/tap', async (req, res) => {
    const { token } = req.body;

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findById(decoded.id);
        await user.addCoins(1);
        
        // Логируем добавление монет
        logger.info(`Пользователь ${user.telegramId} получил 1 монету. Баланс: ${user.balance + 1}`);
        res.json({ balance: user.balance });
    } catch (error) {
        logger.error('Ошибка при обработке тапа:', error);
        res.status(401).json({ message: 'Неверный токен' });
    }
});

// Получение заданий
router.get('/tasks', async (req, res) => {
    const tasks = await Task.find();
    res.json(tasks);
});

// Выполнение задания
router.post('/complete-task', async (req, res) => {
    const { token, taskId } = req.body;

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findById(decoded.id);
        const task = await Task.findById(taskId);

        // Логируем выполнение задания
        logger.info(`Пользователь ${user.telegramId} выполняет задание: ${task.description}`);

        if (task.type === 'referral') {
            const requiredCount = 5; // Количество необходимых рефералов
            if (user.referrals.length >= requiredCount) {
                await user.addCoins(task.coins);
                logger.info(`Пользователь ${user.telegramId} выполнено реферальное задание. Баланс: ${user.balance}`);
            } else {
                return res.status(400).json({ message: 'Недостаточно рефералов' });
            }
        } else if (task.type === 'simple') {
            await user.addCoins(task.coins);
        }

        res.json({ balance: user.balance });
    } catch (error) {
        logger.error('Ошибка при выполнении задания:', error);
        res.status(401).json({ message: 'Неверный токен' });
    }
});

// Регистрация рефералов
router.post('/referral', async (req, res) => {
    const { token, referralId } = req.body;

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findById(decoded.id);
        const referrer = await User.findOne({ telegramId: referralId });

        // Логируем регистрацию реферала
        logger.info(`Пользователь ${user.telegramId} пытается зарегистрировать реферала ${referralId}`);

        if (referrer && !referrer.referrals.includes(user._id)) {
            referrer.referrals.push(user._id);
            await referrer.addCoins(30000); // Награда для реферера
            await referrer.save();
            logger.info(`Пользователь ${referrer.telegramId} получил 30000 монет за реферала ${user.telegramId}`);
        }

        res.json({ message: 'Реферал зарегистрирован' });
    } catch (error) {
        logger.error('Ошибка при регистрации реферала:', error);
        res.status(401).json({ message: 'Неверный токен' });
    }
});

// Получение списка рефералов
router.get('/referrals', async (req, res) => {
    const { token } = req.headers;

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findById(decoded.id).populate('referrals', 'telegramId');
        res.json(user.referrals);
    } catch (error) {
        logger.error('Ошибка при получении рефералов:', error);
        res.status(401).json({ message: 'Неверный токен' });
    }
});

module.exports = router;