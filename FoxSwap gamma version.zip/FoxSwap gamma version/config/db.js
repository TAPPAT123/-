const mongoose = require('mongoose');

// Подключение к базе данных MongoDB
mongoose.connect('mongodb://dima:12345678@rc1b-f0ssrprlowr17co5.mdb.yandexcloud.net:27018/users?replicaSet=rs01&ssl=true&tlsCAFile=root.crt',)
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error('MongoDB connection error:', err));