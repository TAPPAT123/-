const mongoose = require('mongoose');

// Схема задания
const taskSchema = new mongoose.Schema({
    description: String,
    coins: Number,
    type: String, // "simple" или "referral"
    link: String,
});

module.exports = mongoose.model('Task', taskSchema);