const mongoose = require('mongoose');

// Схема пользователя
const userSchema = new mongoose.Schema({
    telegramId: { type: String, unique: true },
    balance: { type: Number, default: 0 },
    referralLink: String,
    referrals: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
});

// Метод для добавления монет
userSchema.methods.addCoins = function(coins) {
    this.balance += coins;
    return this.save();
};

module.exports = mongoose.model('User', userSchema);