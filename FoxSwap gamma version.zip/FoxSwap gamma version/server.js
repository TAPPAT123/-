const express = require('express');
const bodyParser = require('body-parser');
const db = require('./config/db');
const apiRoutes = require('./routes/api');
const errorHandler = require('./middleware/errorHandler');
require('dotenv').config(); // Загружаем переменные окружения

const app = express();
const PORT = process.env.PORT || 3000;
const cors = require('cors');

const corsOptions = {
  origin: '*', // Разрешить запросы с любого источника (ОПАСНО!)
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE', // Разрешить все HTTP методы
  preflightContinue: true, // Разрешить preflight запросы
  optionsSuccessStatus: 204, // Отправлять 204 код ответа на preflight запросы
  allowedHeaders: '*', // Разрешить все заголовки 
  exposedHeaders: '*', // Разрешить доступ ко всем заголовкам ответа 
  credentials: true // Разрешить отправку кук (ОПАСНО!)
};

app.use(cors(corsOptions));
// Middleware
app.use(bodyParser.json());
app.use('/api', apiRoutes);

// Обработка ошибок
app.use(errorHandler);

// Запуск сервера
app.listen(PORT, () => {
    console.log(`Сервер запущен на порту ${PORT}`);
});